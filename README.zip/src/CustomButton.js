export default function CustomButton() {
    function handleClick() {
        alert('Voce clicou aqui :)');
    }
    return(
        <button onClick={handleClick}>
            Clica ni mim
        </button>
    )
}